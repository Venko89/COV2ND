# D2-Semester-1-LEGO-EV3-project

This is for our maze solving robot using a lego EV3.

Crdits:
Tom Hazell
Arch Ldn
Mir Gabare
Ryan Evans
Venko Dimitrov
Zac Davis
